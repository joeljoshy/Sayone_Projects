#!/bin/bash
now=$(date +"%T")
echo "Current time :$now"
